// Service worker: intercetta gli eventi push in arrivo dal server
// e mostra la notifica, anche a browser/app chiusa.

self.addEventListener("push", event => {
  let data = { title: "Bollettino Unico", body: "Aggiornamento sulla tua tratta.", url: "/" };
  try {
    if (event.data) data = { ...data, ...event.data.json() };
  } catch {
    // payload non JSON: usiamo i valori di default
  }

  const options = {
    body: data.body,
    icon: "/icon.png",
    badge: "/icon.png",
    data: { url: data.url || "/" }
  };

  event.waitUntil(self.registration.showNotification(data.title, options));
});

// Al tap sulla notifica, apre (o porta in primo piano) la pagina
self.addEventListener("notificationclick", event => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || "/";
  event.waitUntil(
    clients.matchAll({ type: "window" }).then(windowClients => {
      for (const client of windowClients) {
        if (client.url.includes(self.location.origin) && "focus" in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});
