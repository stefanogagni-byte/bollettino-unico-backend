require("dotenv").config();
const express = require("express");
const path = require("path");
const { saveSubscription, removeSubscription } = require("./lib/store");
const { configuraVapid } = require("./lib/push");
const { avviaPoller, controllaBollettini } = require("./lib/poller");
const { fetchBollettini } = require("./lib/source");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// Chiave pubblica VAPID, serve al frontend per iscriversi alle push
app.get("/api/vapid-public-key", (req, res) => {
  res.json({ key: process.env.VAPID_PUBLIC_KEY || null });
});

// Elenco bollettini correnti (per popolare il calendario nel frontend)
app.get("/api/bollettini", async (req, res) => {
  const bollettini = await fetchBollettini();
  res.json(bollettini);
});

// Iscrizione: il browser manda la subscription push + le tratte da seguire
app.post("/api/iscrivi", (req, res) => {
  const { subscription, tratte } = req.body;
  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: "subscription mancante o non valida" });
  }
  const record = saveSubscription(subscription, tratte);
  res.json({ ok: true, tratte: record.tratte });
});

// Disiscrizione
app.post("/api/disiscrivi", (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) return res.status(400).json({ error: "endpoint mancante" });
  removeSubscription(endpoint);
  res.json({ ok: true });
});

// Utile in sviluppo: forza subito un controllo invece di aspettare il prossimo giro
app.post("/api/forza-controllo", async (req, res) => {
  await controllaBollettini();
  res.json({ ok: true });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Bollettino Unico backend attivo su http://localhost:${PORT}`);
  const vapidOk = configuraVapid();
  if (vapidOk) avviaPoller();
  else console.warn("Poller NON avviato: configura le chiavi VAPID nel file .env prima di procedere.");
});
